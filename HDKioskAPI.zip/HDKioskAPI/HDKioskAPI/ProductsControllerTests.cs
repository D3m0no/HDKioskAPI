﻿using Moq;
using HDKioskAPI.Controllers;
using HDKioskAPI.Data;
using HDKioskAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

public class ProductsControllerTests
{
    [Fact]
    public async Task GetProducts_ReturnsOkResult_WithListOfProducts()
    {
        // Arrange
        var products = new List<Product>
        {
            new Product { Id = 1, Name = "Pizza Margherita", Price = 25.50m, Category = "Pizza" },
            new Product { Id = 2, Name = "Burger", Price = 15.00m, Category = "Burgers" }
        }.AsQueryable(); // Zmieniamy listę na IQueryable

        var mockSet = new Mock<DbSet<Product>>();
        mockSet.As<IQueryable<Product>>()
            .Setup(m => m.Provider).Returns(products.Provider);
        mockSet.As<IQueryable<Product>>()
            .Setup(m => m.Expression).Returns(products.Expression);
        mockSet.As<IQueryable<Product>>()
            .Setup(m => m.ElementType).Returns(products.ElementType);
        mockSet.As<IQueryable<Product>>()
            .Setup(m => m.GetEnumerator()).Returns(products.GetEnumerator());

        var mockContext = new Mock<AppDbContext>();
        mockContext.Setup(m => m.Products).Returns(mockSet.Object);

        var controller = new ProductsController(mockContext.Object);

        // Act
        var result = await controller.GetProducts();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result); // Sprawdzamy, czy wynik to OkObjectResult
        var returnedProducts = Assert.IsAssignableFrom<List<Product>>(okResult.Value); // Sprawdzamy, czy zwrócony obiekt to lista produktów
        Assert.Equal(2, returnedProducts.Count); // Sprawdzamy, że zwrócone produkty mają odpowiednią liczbę elementów
    }
}
