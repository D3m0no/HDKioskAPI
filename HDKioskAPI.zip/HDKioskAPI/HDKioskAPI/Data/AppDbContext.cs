﻿using Microsoft.EntityFrameworkCore;
using HDKioskAPI;
using HDKioskAPI.Models;

namespace HDKioskAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Product> Products { get; set; }
    }
}
